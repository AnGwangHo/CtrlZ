// JavaScript Document

var fadeShow = $(".background").fadeShow({



   correctRatio: true,



   shuffle: true,



   speed: 2500,



   images: ['/html/images/main_image.jpg',



          '/html/images/main_image.jpg']




});